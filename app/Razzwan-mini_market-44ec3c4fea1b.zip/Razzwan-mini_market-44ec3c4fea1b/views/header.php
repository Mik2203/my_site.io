<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8" />
        <title>Mini market</title>
        <link rel="stylesheet" href="views/css/style.css" />
    </head>
    <body>

        <div id="wrapper">

                <div class="main-menu-wrapper">
                    <div class="main-menu">
                        <ul class="homepage">
                            <li><a href="?page=main" >Mini market</a></li>
                        </ul>
                        <ul class="menu-right">
                            <li><a href="?page=ledenec" >Леденцы</a></li>
                            <li><a href="?page=about" >О компании</a></li>
                            <li><a href="?page=cart" class="cart">Корзина</a></li>
                        </ul>
                    </div>
                </div>
                <div style="clear: both"></div>


            <div class="content">
                <div class="main">