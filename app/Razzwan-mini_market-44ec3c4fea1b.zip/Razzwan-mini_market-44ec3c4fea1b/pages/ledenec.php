<?php for ($i=1; $i<=12; $i++){?>
    <div class="item">
        <h2>леденец № <?=$i;?></h2>
    </div>
<?php }?>

